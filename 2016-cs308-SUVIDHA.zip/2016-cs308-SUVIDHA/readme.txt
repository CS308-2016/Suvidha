Project Name: SUVIDHA

Team Members:
1. Deepak Verma - 120050012
2. Tapish Raniwal - 120050023
3. Naveen Sagar - 120050026
4. Bhupendra Singh Bhuarya - 120050040

Project Description: Suvidha is weather controlled home automation system which takes data from temperature(DHT11),
 humidity(DHT11), LDR(light intensity sensor), PIR motion sensor (HC-SR501) and control light intensity and fan speed.

Video Links :
Screen cast : https://www.youtube.com/watch?v=x90EsSLGHhw&feature=youtu.be
Working and Fucntionality : https://www.youtube.com/watch?v=Q-MBhe6cl6U&feature=youtu.be
