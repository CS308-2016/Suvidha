
How to HTML page(user interface) for manual control
---------------------------------------------------------------
1. Run the code with energia
2. Copy the IP address that is shown in serial terminal.
3. Paste the IP in the browser and the HTML page will appear   
