2016 - CS308  Group 13 : Project Name : Suvidha 
================================================ 
 
Group Info: 
------------ 
Tapish Raniwal 120050023
Bhupendra Singh Bhuarya 120050040
Deepak Verma 120050012
Naveen Sagar 120050026

 

Project Description 
------------------- 
Suvidha is weather controlled home automation system which takes data from temperature(DHT11), humidity(DHT11), LDR(light intensity sensor), PIR motion sensor (HC-SR501) and control light intensity and fan speed.
 
Technologies Used 
------------------- 
   Embedded C     


How to HTML page(user interface) for manual control
---------------------------------------------------------------
1. Run the code with energia
2. Copy the IP address that is shown in serial terminal.
3. Paste the IP in the browser and the HTML page will appear    
 
Demonstration Video 
=========================  
Add the youtube link of the screencast of your project demo.

References 

 
Please give references to importance resources.  
Instructions to interface Cloud service to tiva - https://github.com/attm2x/m2x-launchpad-energia
Information about CC3100 - http://www.ti.com/tool/cc3100boost
Info. about TIVA tm4c123g LaunchPad - http://www.ti.com/tool/ek-tm4c123gxl
Info. about DHT11 Sensor - https://www.adafruit.com/product/386
Info. about Proximity Sensor - https://learn.adafruit.com/pir-passive-infrared-proximity-motion-sensor/testing-a-pir
Info. about LDR - http://www.instructables.com/id/How-to-Use-a-Light-Dependent-Resistor-LDR/
Pin map for energia- http://energia.nu/pin-maps/
